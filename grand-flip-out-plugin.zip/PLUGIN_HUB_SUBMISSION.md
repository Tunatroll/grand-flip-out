# Grand Flip Out — Plugin Hub Submission Guide

## Submission Steps for account: tuna troll

### 1. Push to GitHub

Create a **public** GitHub repository under the `tuna troll` account:

```bash
# Initialize repo
cd grand-flip-out
git init
git add .
git commit -m "Grand Flip Out v1.0.0 — Comprehensive GE flipping assistant"
git remote add origin https://github.com/tunatroll/grand-flip-out.git
git push -u origin main
```

### 2. Get the Commit Hash

```bash
git rev-parse HEAD
# Example output: a1b2c3d4e5f6...
```

### 3. Fork the Plugin Hub

1. Go to https://github.com/runelite/plugin-hub
2. Click "Fork"
3. In your fork, create a new file: `plugins/grand-flip-out`

### 4. Create the Manifest

File: `plugins/grand-flip-out`

```
repository=https://github.com/tunatroll/grand-flip-out.git
commit=<PASTE_YOUR_40_CHAR_COMMIT_HASH_HERE>
```

### 5. Submit Pull Request

1. Create a PR from your fork to `runelite/plugin-hub`
2. Title: `Add Grand Flip Out — GE flipping assistant`
3. Description:

```
## Grand Flip Out

A comprehensive Grand Exchange flipping assistant with:
- Multi-source pricing (OSRS Wiki Real-time Prices API)
- JTI (Jagex Trade Index) composite scoring engine
- Dump/crash detection with knowledge-based analysis
- Technical analysis (RSI, EMA, MACD, Bollinger Bands)
- Recipe flip detection (herb cleaning, gem cutting, enchanting)
- Flip tracking with profit/loss analysis
- Risk management and position sizing
- Multi-account portfolio monitoring (info only)
- Configurable hotkeys throughout

**Jagex Compliance:**
- Information only — no automation of any game actions
- All buy/sell offers placed manually by the player
- Uses only RuneLite's official event API
- No game packets sent, no memory read beyond RuneLite Client API
- BSD 2-Clause license
```

### 6. Wait for Review

RuneLite reviewers will:
- Check CI build passes
- Verify no malicious code
- Verify compliance with Jagex rules
- Check no previously rejected features are included

### Required Files Checklist

- [x] `build.gradle` — Gradle build with RuneLite dependencies
- [x] `settings.gradle` — rootProject.name = 'grand-flip-out'
- [x] `runelite-plugin.properties` — Plugin metadata
- [x] `LICENSE` — BSD 2-Clause
- [x] `src/main/java/com/fliphelper/GrandFlipOutPlugin.java` — Main plugin
- [x] `src/main/java/com/fliphelper/GrandFlipOutConfig.java` — Configuration
- [x] All supporting Java files in proper packages

### Build Verification

Before submitting, verify the plugin builds:

```bash
./gradlew build
```

All tests should pass and no warnings about Jagex rule violations should appear.
